# Social-Media-App-ReachMe-
This is a Socila Media Application for Android, here you can add stories, post some photos, like your friend photos, comment on your friends posts, follow your friends, and can do many more things.

**Login Page:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093612-15379abb-8ff4-4a84-9603-d86b6e3845d4.jpg" width="200" height="400"   />
</p>

**Register Page:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093630-61ec1537-cad4-4794-af9d-29b2b7a06102.jpg" width="200" height="400"   />
</p>

**Home Page:-**


<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093643-c70131c0-a688-4902-9165-38b716717602.jpg" width="200" height="400"   />
  <img src="https://user-images.githubusercontent.com/98186477/187093650-8330f444-20db-4f70-a45e-a7e1382a32f2.jpg" width="200" height="400"   />
</p>

**Story:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093661-fc39f2ff-1e3b-4b51-9ac4-c902bd6d90a8.jpg" width="200" height="400"   />
</p>


**Notification:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093687-5ee4625b-797a-4efa-b408-664bd0a5c0fb.jpg" width="200" height="400"   />
</p>


**Add Friends:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093697-11fe1beb-815e-4fce-a5cd-5a576b26868e.jpg" width="200" height="400"   />
</p>


**Profile:-**

<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093712-c89b30b9-93ed-4980-9fc2-14d9116ee19b.jpg" width="200" height="400"   />
</p>

**Add Post:-**
<p align="center">
  <img src="https://user-images.githubusercontent.com/98186477/187093775-914f73a7-f5b4-4105-9f0d-047a1a291a7c.jpg" width="200" height="400"   />
</p>

<p align="center">
  <b>Download and try the app from <i><a href = "https://drive.google.com/file/d/1mcxSpPAKGp3PC6p2id3bTPju0UWxTnId/view">Here</i></b>
</p>



